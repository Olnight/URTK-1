import { createApp, defineComponent } from './vendor/vue.esm-browser.js';

const App = defineComponent({
    name: 'App',
    data() {
        return {
            firstOperand: 0,
            secondOperand: 0,
            operation: '',
        };
    },

    computed: {
        operationResult() {
            switch (this.operation) {
                case 'sum':
                    return this.firstOperand + this.secondOperand;
                case 'subtract':
                    return this.firstOperand - this.secondOperand;
                case 'multiply':
                    return this.firstOperand * this.secondOperand;
                case 'divide':
                    return this.firstOperand / this.secondOperand;
                default:
                    return 0;
            }
        }
    },
});

const app = createApp(App);

const vm = app.mount('#app');

window.vm = vm;